@props(['text'])

{!! $text !!}
